import time 
import random


print("Welcome to the game of life")
print("here u wait for eternity, to suffer, to die alone")
time.sleep(10000000000000)