OMGGGGGG

This is te README for this projevct which I got rid of 

You can run this project and get a dare to kill someone so be ready

![HEHEHAHA](https://i.ytimg.com/vi/3jkrk0BDbrA/maxresdefault.jpg)